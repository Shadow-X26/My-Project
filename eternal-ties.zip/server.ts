import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database("database.sqlite");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    bio TEXT,
    religion TEXT,
    age INTEGER,
    height TEXT,
    profession TEXT,
    education TEXT,
    gender TEXT,
    location TEXT,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS interests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id),
    FOREIGN KEY (receiver_id) REFERENCES users(id),
    UNIQUE(sender_id, receiver_id)
  );
`);

// Add some sample data if empty
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get().count;
if (userCount === 0) {
  const insertUser = db.prepare("INSERT INTO users (email, password, name) VALUES (?, ?, ?)");
  const insertProfile = db.prepare(`
    INSERT INTO profiles (user_id, bio, religion, age, height, profession, education, gender, location, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const u1 = insertUser.run("sarah@example.com", "password", "Sarah Ahmed").lastInsertRowid;
  insertProfile.run(u1, "Loves travel and reading.", "Muslim", 26, "5'4", "Architect", "Masters in Architecture", "female", "Dhaka", "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400");

  const u2 = insertUser.run("rahul@example.com", "password", "Rahul Sharma").lastInsertRowid;
  insertProfile.run(u2, "Seeking a partner who values family.", "Hindu", 29, "5'10", "Software Engineer", "B.Tech CSE", "male", "Mumbai", "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400");

  const u3 = insertUser.run("priya@example.com", "password", "Priya Das").lastInsertRowid;
  insertProfile.run(u3, "Artist and dreamer.", "Christian", 24, "5'2", "Graphic Designer", "BFA", "female", "Kolkata", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/profiles", (req, res) => {
    const profiles = db.prepare(`
      SELECT p.*, u.name 
      FROM profiles p 
      JOIN users u ON p.user_id = u.id
      ORDER BY p.created_at DESC
    `).all();
    res.json(profiles);
  });

  app.get("/api/profiles/:id", (req, res) => {
    const profile = db.prepare(`
      SELECT p.*, u.name, u.email
      FROM profiles p 
      JOIN users u ON p.user_id = u.id
      WHERE p.id = ?
    `).get(req.params.id);
    if (!profile) return res.status(404).json({ error: "Profile not found" });
    res.json(profile);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
