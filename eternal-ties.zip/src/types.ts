export interface Profile {
  id: number;
  user_id: number;
  name: string;
  bio: string;
  religion: string;
  age: number;
  height: string;
  profession: string;
  education: string;
  gender: string;
  location: string;
  image_url: string;
  created_at: string;
}
