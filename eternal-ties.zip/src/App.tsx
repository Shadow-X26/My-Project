/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Heart, Search, User, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Home from "./pages/Home";
import Browse from "./pages/Browse";
import ProfileDetail from "./pages/ProfileDetail";
import Login from "./pages/Login";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-[#0F0F0F]/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center transition-transform group-hover:scale-110">
              <Heart className="w-4 h-4 text-black fill-black" />
            </div>
            <span className="font-serif text-xl tracking-[0.2em] uppercase text-gold pt-1">EternalTies</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <Link to="/browse" className="text-[10px] font-bold hover:text-gold transition-colors uppercase tracking-[0.2em] text-brand-50/70">Browse</Link>
            <Link to="/matches" className="text-[10px] font-bold hover:text-gold transition-colors uppercase tracking-[0.2em] text-brand-50/70">My Matches</Link>
            <Link to="/dashboard" className="text-[10px] font-bold hover:text-gold transition-colors uppercase tracking-[0.2em] text-brand-50/70">Dashboard</Link>
            <Link to="/login" className="bg-gold text-black px-6 py-2 rounded-lg text-[10px] font-black hover:bg-white transition-all uppercase tracking-[0.2em]">Sign In</Link>
          </div>

          <button className="md:hidden text-gold" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-brand-950 border-b border-white/10 px-4 py-8 flex flex-col gap-6"
          >
            <Link to="/browse" onClick={() => setIsOpen(false)} className="text-xl font-serif text-gold">Browse Profiles</Link>
            <Link to="/" onClick={() => setIsOpen(false)} className="text-xl font-serif">Success Stories</Link>
            <Link to="/login" onClick={() => setIsOpen(false)} className="text-xl font-serif">Sign In</Link>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col bg-[#0F0F0F]">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/browse" element={<Browse />} />
            <Route path="/profile/:id" element={<ProfileDetail />} />
            <Route path="/login" element={<Login />} />
          </Routes>
        </main>
        <footer className="bg-brand-950 border-t border-white/5 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-12">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-gold fill-gold" />
                <span className="font-serif text-xl tracking-[0.2em] uppercase text-gold pt-1">EternalTies</span>
              </div>
              <div className="flex justify-center gap-10 text-[10px] uppercase tracking-[0.2em] font-bold opacity-30">
                <a href="#" className="hover:opacity-100 transition-opacity">Privacy</a>
                <a href="#" className="hover:opacity-100 transition-opacity">Terms</a>
                <a href="#" className="hover:opacity-100 transition-opacity">Safety</a>
                <a href="#" className="hover:opacity-100 transition-opacity">Support</a>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-brand-50/40 font-serif italic text-lg mb-8">
                "Finding your companion for this world and the hereafter."
              </p>
              <div className="flex items-center justify-center gap-2 text-[10px] opacity-20 font-bold uppercase tracking-widest">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                System Live • Version 2.4.1 (Laravel 10.x)
              </div>
            </div>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}
