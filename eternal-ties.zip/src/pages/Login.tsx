import { motion } from "motion/react";
import { Heart, ArrowRight, ShieldCheck, Lock } from "lucide-react";

export default function Login() {
  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 bg-[#0F0F0F] relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gold/5 blur-[150px] rounded-full pointer-events-none" />
      
      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-md w-full bg-brand-900/60 backdrop-blur-2xl p-12 lg:p-16 rounded-[2.5rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.8)] border border-white/10 text-center relative z-10"
      >
        <div className="flex justify-center mb-10">
          <div className="w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center p-4">
             <div className="w-full h-full bg-gold rounded-full flex items-center justify-center">
                <Lock className="w-6 h-6 text-black" />
             </div>
          </div>
        </div>
        
        <h1 className="text-4xl text-white mb-4">Secure Access</h1>
        <p className="text-brand-50/40 font-serif mb-12 italic text-lg leading-relaxed">Enter the archive to continue your search for shared values.</p>
        
        <div className="space-y-6 mb-12">
          <div className="group text-left">
            <label className="text-[9px] font-black uppercase tracking-[0.4em] text-gold/40 mb-3 block leading-none ml-4 transition-colors group-focus-within:text-gold">Candidate Email</label>
            <input 
              type="email" 
              placeholder="name@archived.com" 
              className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-gold/50 focus:bg-white/10 transition-all font-bold text-[10px] uppercase tracking-widest text-white placeholder:text-white/20"
            />
          </div>
          <div className="group text-left">
            <label className="text-[9px] font-black uppercase tracking-[0.4em] text-gold/40 mb-3 block leading-none ml-4 transition-colors group-focus-within:text-gold">Access Key</label>
            <input 
              type="password" 
              placeholder="••••••••" 
              className="w-full px-8 py-5 bg-white/5 border border-white/10 rounded-2xl focus:outline-none focus:border-gold/50 focus:bg-white/10 transition-all font-bold text-[10px] uppercase tracking-widest text-white placeholder:text-white/20"
            />
          </div>
        </div>
        
        <button className="w-full bg-gold text-black py-5 rounded-xl font-black uppercase tracking-[0.3em] text-[11px] hover:bg-white transition-all flex items-center justify-center gap-3 shadow-2xl mb-10 group">
          Authorize <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
        </button>
        
        <div className="flex flex-col gap-8">
          <a href="#" className="text-[9px] font-black uppercase tracking-[0.3em] text-white/20 hover:text-gold transition-colors">Access Recovery Protocol</a>
          
          <div className="pt-10 border-t border-white/5 flex flex-col items-center gap-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">New to the Archive?</p>
            <a href="#" className="inline-flex items-center gap-3 text-gold font-black uppercase tracking-[0.3em] text-[10px] group">
              Submit Application <ShieldCheck className="w-4 h-4 group-hover:animate-pulse" />
            </a>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
