import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "motion/react";
import { Heart, MessageSquare, MapPin, Briefcase, GraduationCap, Ruler, Church, Calendar, ChevronLeft, ShieldCheck, Mail, Share2, MoreHorizontal } from "lucide-react";
import { Profile } from "../types";

export default function ProfileDetail() {
  const { id } = useParams();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/profiles/${id}`)
      .then(res => res.json())
      .then(data => {
        setProfile(data);
        setLoading(false);
      });
  }, [id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#0F0F0F]">
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
        className="w-12 h-12 border-2 border-gold border-t-transparent rounded-full shadow-[0_0_20px_rgba(197,160,89,0.3)]"
      />
    </div>
  );

  if (!profile) return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-[#0F0F0F]">
      <h1 className="text-4xl mb-4 text-white">Dossier Unavailable</h1>
      <Link to="/browse" className="text-gold font-black uppercase tracking-[0.3em] text-xs border-b border-gold/30 pb-2">Return to Archive</Link>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0F0F0F] pb-32">
      {/* Background Header */}
      <div className="h-[30vh] bg-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] to-transparent" />
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-10">
        <div className="flex flex-col lg:flex-row gap-20">
          
          {/* Left Column: Image & Quick Stats */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full lg:w-[450px] shrink-0"
          >
            <div className="aspect-[4/5] rounded-[2rem] overflow-hidden shadow-[0_40px_100px_-20px_rgba(0,0,0,0.8)] relative border border-white/10">
              <img 
                src={profile.image_url} 
                className="w-full h-full object-cover"
                alt={profile.name}
              />
              <div className="absolute bottom-10 left-10 right-10 flex gap-4">
                <button className="flex-grow bg-gold text-black py-5 rounded-xl font-black uppercase tracking-[0.2em] text-[10px] hover:bg-white transition-all shadow-2xl flex items-center justify-center gap-2">
                  <Heart className="w-4 h-4 fill-black" /> Express Interest
                </button>
                <button className="w-16 h-16 bg-black/60 backdrop-blur-xl border border-white/20 text-white rounded-xl flex items-center justify-center hover:bg-gold hover:text-black transition-all">
                  <MessageSquare className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="mt-12 space-y-4">
               <div className="p-8 bg-brand-900 border border-white/5 rounded-3xl flex items-center gap-6">
                 <div className="w-14 h-14 bg-green-500/10 rounded-full flex items-center justify-center shrink-0">
                   <ShieldCheck className="text-green-500 w-7 h-7" />
                 </div>
                 <div>
                   <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-white/50 mb-1 leading-none">Security Rating</h4>
                   <p className="text-lg font-serif text-white">Fully Verified Candidate</p>
                 </div>
               </div>
               
               <div className="flex gap-4">
                  <button className="flex-1 p-6 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center text-white/30 hover:text-gold transition-colors">
                    <Share2 className="w-5 h-5" />
                  </button>
                  <button className="flex-1 p-6 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center text-white/30 hover:text-gold transition-colors">
                    <Mail className="w-5 h-5" />
                  </button>
                  <button className="flex-1 p-6 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center text-white/30 hover:text-gold transition-colors">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
               </div>
            </div>
          </motion.div>

          {/* Right Column: Detailed Info */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex-1 lg:pt-32"
          >
            <div className="mb-20">
              <div className="flex items-center gap-6 mb-8 uppercase tracking-[0.3em] text-[9px] font-black text-gold">
                <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-gold" /> {profile.religion}</span>
                <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-gold/40" /> {profile.gender}</span>
                <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-gold/40" /> 98% Compatibility</span>
              </div>
              <h1 className="text-8xl mb-4 text-white leading-none">{profile.name}</h1>
              <p className="text-3xl font-serif italic text-brand-50/30 leading-relaxed max-w-xl">
                {profile.profession} based in {profile.location}
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-12 mb-20 border-y border-white/5 py-12">
              <div className="space-y-1">
                <div className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20 mb-3 leading-none">Age Range</div>
                <p className="text-xl font-serif text-white">{profile.age} Years</p>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20 mb-3 leading-none">Height Stature</div>
                <p className="text-xl font-serif text-white">{profile.height}</p>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20 mb-3 leading-none">Academic Profile</div>
                <p className="text-xl font-serif text-white">{profile.education}</p>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] font-black uppercase tracking-[0.4em] text-white/20 mb-3 leading-none">Cultural Root</div>
                <p className="text-xl font-serif text-white">{profile.religion}</p>
              </div>
            </div>

            <div className="mb-24">
              <h3 className="text-[9px] font-black uppercase tracking-[0.5em] text-gold mb-10 leading-none">Philosophical Abstract</h3>
              <p className="text-3xl font-serif leading-relaxed text-brand-50/70 italic">
                "{profile.bio}"
              </p>
            </div>

            <div className="space-y-32">
              <section>
                <h3 className="text-[9px] font-black uppercase tracking-[0.5em] text-white/20 mb-12">Value Convergence Metrics</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {[
                    { label: "Kinship Priority", value: "Significant / Family-Centric" },
                    { label: "Faith Observance", value: "Practicing / Devout" },
                    { label: "Professional Trajectory", value: "Elite / Growth-Focused" },
                    { label: "Disposition", value: "Sophisticated / Eloquent" },
                  ].map((trait, i) => (
                    <div key={i} className="p-8 bg-white/5 border border-white/10 rounded-3xl transition-transform hover:-translate-y-1">
                      <div className="text-[9px] font-black uppercase tracking-[0.3em] text-gold/40 mb-3 leading-none">{trait.label}</div>
                      <div className="text-xl font-serif text-white">{trait.value}</div>
                    </div>
                  ))}
                </div>
              </section>

              <section>
                <h3 className="text-[9px] font-black uppercase tracking-[0.5em] text-white/20 mb-12">Desired Companion Attributes</h3>
                <div className="flex flex-wrap gap-4">
                  {["Eloquence", "Faith-Driven", "Academic Depth", "Patience", "Nobility", "Authenticity"].map((tag, i) => (
                    <span key={i} className="px-8 py-3 bg-white/5 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-[0.3em] text-white/60 hover:text-gold hover:border-gold/30 transition-all cursor-default">
                      {tag}
                    </span>
                  ))}
                </div>
              </section>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
