import { motion } from "motion/react";
import { Search, Heart, ShieldCheck, Users, Sparkles, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Profile } from "../types";

export default function Home() {
  const [featuredProfiles, setFeaturedProfiles] = useState<Profile[]>([]);

  useEffect(() => {
    fetch("/api/profiles")
      .then(res => res.json())
      .then(data => setFeaturedProfiles(data.slice(0, 3)));
  }, []);

  return (
    <div className="flex flex-col bg-[#0F0F0F]">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover opacity-30"
            alt="Wedding ceremony"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F0F0F] via-[#0F0F0F]/80 to-transparent" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1 }}
            className="max-w-2xl"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="h-[1px] w-12 bg-gold/50" />
              <span className="text-gold text-[10px] font-black uppercase tracking-[0.4em]">Established 2026</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-serif mb-6 leading-none text-white">
              The Path to <br />
              <span className="italic text-gold">Eternal Companion</span>
            </h1>
            <p className="text-xl font-serif mb-12 text-brand-50/60 max-w-lg leading-relaxed">
              Discreet and intentional matchmaking for discerning individuals seeking shared values and high-trust introductions.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6">
              <Link 
                to="/browse" 
                className="bg-gold text-black px-12 py-5 rounded-lg text-[11px] font-black hover:bg-white transition-all text-center uppercase tracking-[0.2em]"
              >
                Start Your Search
              </Link>
              <button 
                className="bg-white/5 backdrop-blur-md border border-white/10 text-white px-10 py-5 rounded-lg text-[11px] font-black hover:bg-white/10 transition-all text-center uppercase tracking-[0.2em]"
              >
                Our Process
              </button>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-10 left-10 right-10 flex justify-between text-white/20 text-[9px] uppercase tracking-[0.4em] font-black hidden md:flex">
          <span>01 Verified Members</span>
          <span className="text-white/40">Secure introductions</span>
          <span>03 Lifestyle Match</span>
        </div>
      </section>

      {/* Featured Profiles */}
      <section className="py-24 bg-[#0F0F0F]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-16">
            <div>
              <h2 className="text-4xl md:text-5xl mb-4 text-white">Curated Matches</h2>
              <p className="text-brand-50/40 font-serif italic text-xl">Laravel Query: Select * from users where verified = true</p>
            </div>
            <Link to="/browse" className="text-[10px] font-bold uppercase tracking-widest text-gold border-b border-gold pb-1 hover:text-white hover:border-white transition-all">View All Results</Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-left">
            {featuredProfiles.map((profile, i) => (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                key={profile.id}
                className="group cursor-pointer bg-white/5 border border-white/10 rounded-2xl overflow-hidden flex flex-col transition-all hover:bg-white/10"
              >
                <Link to={`/profile/${profile.id}`} className="flex flex-col h-full">
                  <div className="aspect-[4/3] overflow-hidden relative">
                    <img 
                      src={profile.image_url} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      alt={profile.name}
                    />
                    <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded text-[10px] font-bold text-gold border border-gold/30 uppercase tracking-widest">
                      {profile.religion}
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-2xl mb-1 text-white">{profile.name}</h3>
                    <p className="text-brand-50/40 uppercase tracking-widest text-[10px] font-bold mb-4">{profile.profession} • {profile.location}</p>
                    <div className="mt-auto flex justify-between items-center">
                      <span className="text-[10px] opacity-40 uppercase tracking-widest font-bold">Age {profile.age}</span>
                      <span className="text-gold text-[10px] font-black uppercase tracking-widest border-b border-gold pb-1 group-hover:text-white group-hover:border-white transition-all">View Profile</span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section className="py-24 border-y border-white/5 bg-brand-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
            <div className="text-center md:text-left">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6 mx-auto md:mx-0">
                <ShieldCheck className="text-gold w-5 h-5" />
              </div>
              <h4 className="text-lg uppercase tracking-widest text-gold mb-3 font-bold">Verification</h4>
              <p className="text-brand-50/50 font-serif text-sm leading-relaxed">Manual review of every candidate to ensure a high-trust community.</p>
            </div>
            <div className="text-center md:text-left">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6 mx-auto md:mx-0">
                <Users className="text-gold w-5 h-5" />
              </div>
              <h4 className="text-lg uppercase tracking-widest text-gold mb-3 font-bold">Security</h4>
              <p className="text-brand-50/50 font-serif text-sm leading-relaxed">Advanced privacy controls to protect your data and visual profile.</p>
            </div>
            <div className="text-center md:text-left">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6 mx-auto md:mx-0">
                <Sparkles className="text-gold w-5 h-5" />
              </div>
              <h4 className="text-lg uppercase tracking-widest text-gold mb-3 font-bold">Precision</h4>
              <p className="text-brand-50/50 font-serif text-sm leading-relaxed">Heuristic-based matching focused on lifestyle and philosophical alignment.</p>
            </div>
            <div className="text-center md:text-left">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6 mx-auto md:mx-0">
                <Heart className="text-gold w-5 h-5" />
              </div>
              <h4 className="text-lg uppercase tracking-widest text-gold mb-3 font-bold">Tradition</h4>
              <p className="text-brand-50/50 font-serif text-sm leading-relaxed">Built with cultural nuances to support honorable family introductions.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-[#0F0F0F] relative overflow-hidden text-center">
        <div className="max-w-3xl mx-auto px-4 relative z-10">
          <div className="flex justify-center mb-8">
             <div className="w-20 h-20 bg-gold rounded-full flex items-center justify-center">
                <Heart className="text-black w-10 h-10 fill-black" />
             </div>
          </div>
          <h2 className="text-5xl md:text-7xl mb-8 leading-none text-white">Your Future <br /> <span className="italic text-gold">Begins Here</span></h2>
          <p className="text-xl text-brand-50/40 mb-12 font-serif max-w-lg mx-auto">Join a curated network where intention meets honor.</p>
          <button className="bg-gold text-black px-16 py-6 rounded-lg text-xs font-black hover:bg-white transition-all uppercase tracking-[0.3em] shadow-2xl">
            Create Exclusive Account
          </button>
        </div>
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[600px] h-[600px] bg-gold/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gold/10 blur-[120px] rounded-full" />
      </section>
    </div>
  );
}
