import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, Filter, MapPin, Briefcase, GraduationCap, ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";
import { Profile } from "../types";

export default function Browse() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("all");

  useEffect(() => {
    fetch("/api/profiles")
      .then(res => res.json())
      .then(data => {
        setProfiles(data);
        setLoading(false);
      });
  }, []);

  const filteredProfiles = profiles.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                         p.profession.toLowerCase().includes(search.toLowerCase()) ||
                         p.location.toLowerCase().includes(search.toLowerCase());
    const matchesGender = genderFilter === "all" || p.gender === genderFilter;
    return matchesSearch && matchesGender;
  });

  return (
    <div className="min-h-screen bg-[#0F0F0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-12 mb-16 border-b border-white/5 pb-16">
          <div className="max-w-xl">
            <div className="flex items-center gap-4 mb-4">
              <div className="h-[1px] w-8 bg-gold/50" />
              <span className="text-gold text-[9px] font-black uppercase tracking-[0.4em]">Database Search</span>
            </div>
            <h1 className="text-5xl md:text-7xl mb-6 text-white">Curated Matches</h1>
            <p className="text-brand-50/40 font-serif italic text-xl leading-relaxed">
              Applying Laravel 10.x filters to find the most compatible profiles based on shared values and professional background.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
            <div className="relative group">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gold group-focus-within:text-white transition-colors" />
              <input 
                type="text" 
                placeholder="Search profiles..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full sm:w-80 pl-14 pr-6 py-5 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-gold/50 focus:bg-white/10 transition-all text-xs font-bold uppercase tracking-widest text-brand-50"
              />
            </div>
            <div className="relative">
              <select 
                value={genderFilter}
                onChange={(e) => setGenderFilter(e.target.value)}
                className="w-full sm:w-60 px-8 py-5 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-gold/50 focus:bg-white/10 transition-all text-[10px] font-black uppercase tracking-[0.2em] appearance-none cursor-pointer text-brand-50"
              >
                <option value="all" className="bg-[#0F0F0F]">Search: All Roles</option>
                <option value="male" className="bg-[#0F0F0F]">Looking for Groom</option>
                <option value="female" className="bg-[#0F0F0F]">Looking for Bride</option>
              </select>
              <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gold pointer-events-none" />
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-48">
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 border-2 border-gold border-t-transparent rounded-full shadow-[0_0_20px_rgba(197,160,89,0.3)]"
            />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <AnimatePresence mode="popLayout">
              {filteredProfiles.map((profile, i) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.05 }}
                  key={profile.id}
                  className="group bg-white/5 border border-white/10 rounded-2xl overflow-hidden flex flex-col transition-all duration-500 hover:bg-white/10 hover:border-gold/30 hover:shadow-[0_20px_50px_-20px_rgba(0,0,0,0.5)]"
                >
                  <Link to={`/profile/${profile.id}`} className="flex flex-col h-full">
                    <div className="aspect-[4/5] overflow-hidden relative">
                      <img 
                        src={profile.image_url} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        alt={profile.name}
                      />
                      <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded text-[9px] font-black text-gold border border-gold/30 uppercase tracking-widest leading-none">
                        98% Match
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent opacity-60" />
                    </div>
                    
                    <div className="p-8 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl text-white mb-1">{profile.name}</h3>
                          <p className="text-[10px] uppercase tracking-widest text-gold font-black">{profile.profession}</p>
                        </div>
                        <span className="text-lg font-serif italic text-brand-50/40">{profile.age}</span>
                      </div>
                      
                      <div className="mt-4 pt-4 border-t border-white/5 space-y-3">
                        <div className="flex items-center gap-3 text-brand-50/40">
                          <MapPin className="w-3 h-3 text-gold/60" />
                          <span className="text-[10px] font-bold uppercase tracking-widest truncate">{profile.location}</span>
                        </div>
                        <div className="flex items-center gap-3 text-brand-50/40">
                          <GraduationCap className="w-3 h-3 text-gold/60" />
                          <span className="text-[10px] font-bold uppercase tracking-widest truncate">{profile.religion}</span>
                        </div>
                      </div>

                      <div className="mt-auto pt-8">
                        <button className="w-full py-4 border-b border-gold text-[10px] font-black uppercase tracking-[0.3em] text-gold hover:text-white hover:border-white transition-all">
                          View Dossier
                        </button>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {!loading && filteredProfiles.length === 0 && (
          <div className="text-center py-48">
            <p className="text-3xl font-serif italic text-brand-50/20 mb-8">No results matching your query found.</p>
            <button 
              onClick={() => {setSearch(""); setGenderFilter("all");}}
              className="text-gold font-black uppercase tracking-[0.3em] text-xs border-b border-gold/30 pb-2 hover:text-white hover:border-white transition-all"
            >
              Reset Search Parameters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
